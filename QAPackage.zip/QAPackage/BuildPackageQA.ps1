﻿##############################################################
# QA Package creation 
#
# Date:22/10/2018, Created By:Sumit Raj (sumit.raj@ekaplus.com)
#
# This script will copy the Incremnetal build 
# so only the Updated file will be copied to QA package
#
# This step will be added in Build definiton post the MS build Step
#
##############################################################




Param(
[Parameter(mandatory=$true)][String]$SourceP,
[Parameter(mandatory=$true)][String]$TargetP,
[Parameter(mandatory=$true)][String]$LogP,
[String]$Date
)

$DesktopAppFolder=@("Help","Themes","x86","x64")
$ScriptRootPath="D:\Scripts"
$LogFile="CMPackage_"+(Get-Date).ToString("dd-MM-yyyy")+".txt"

# For creating the Log file with timestamp
if(Test-path -path "$LogP\$LogFile"){

    write-host "LogFileExist"

}
else{

    New-Item -Path $LogP -Name $LogFile -ItemType "file"

}

# For Testing

#[String]$SourceP="\\10.0.82.10\EnCompassVersionControl\Sample\`$Install-8.5\InSightCMProd"
#[String]$TargetP="\\10.0.82.10\EnCompassVersionControl\Sample\Source"
#[String]$SourceP="\\10.0.82.10\EnCompassVersionControl\Sample\Source"
#[String]$TargetP="\\10.0.82.10\EnCompassVersionControl\Sample\`$Install-8.5\InSightCMProd"


[System.IO.Directory]::Exists($SourceP)
[System.IO.Directory]::Exists($TargetP)
$Global:Date

#Getting the current date for copying the Files
if($Date -eq ''){

$Global:Date=(Get-Date).ToString("yyyyMMdd")

}
else{

# For specific date, from the Parameter
$Global:Date=$Date

}

write-host "The Date is " $Global:Date

# This function will be used for Service and Spreadsheet
Function CopyLatestFile{
Param(
[Parameter(mandatory=$true)][String]$Item,
[Parameter(mandatory=$true)][String]$SourceP,
[Parameter(mandatory=$true)][String]$TargetP)

    try{

	if([System.IO.Directory]::Exists($TargetP)){
    "`n Info: Copying... $Item" | out-file -FilePath $LogP\$LogFile -Append
	Copy-Item $SourceP\$Item -Destination $TargetP -Recurse -Force
    "`n Info: Copied $Item to $TargetP" | out-file -FilePath $LogP\$LogFile -Append
    
	}
	else{
    "`n Error: Target Path Does not exist! Please make sure the Target path is correct" | out-file -FilePath $LogP\$LogFile -Append
	Write-Verbose -Verbose "Target Path does Not exist"

	}
	}
	catch{
    "`n Exception: Occured During the Copy $_.Exception" | out-file -FilePath $LogP\$LogFile -Append
	Write-Host "Exception Occured duriing the Copying the File" $_.Exception

	}


}

# This function will be used for Service and Spreadsheet
function GetLatestFile{

Param(
[Parameter(mandatory=$true)][String]$SourceP,
[Parameter(mandatory=$true)][String]$TargetP)

try{

	if([System.IO.Directory]::Exists($SourceP)){
    
	$LatestFile=Get-ChildItem -Path $SourceP | Where-Object {$_.LastWriteTime.ToString('yyyyMMdd') -ge $Global:Date } 

	foreach($File in $LatestFile){

	Write-Host "the File is " $File
    "`n Info: Latest File is $File" | out-file -FilePath $LogP\$LogFile -Append 
	CopyLatestFile $File $SourceP $TargetP

	}
	
	}
	else{
    "`n Error: Source Path $SourceP does not exist" | out-file -FilePath $LogP\$LogFile -Append 
	Write-Verbose -Verbose "The Source Path does not exist"
    
	}
	
    }
	catch{
    "`n Exception: Occured during the Getlatestfile" | out-file -FilePath $LogP\$LogFile -Append 
	Write-Host "Exception Occured duriing the getting Files" $_.Exception

	}


}

Function sendMailMessage{

outlook.office365.com
$secpasswd = ConvertTo-SecureString "ranjanaverma" -AsPlainText -Force
$PWD=New-Object System.Management.Automation.PSCredential("sumit.raj0103@gmail.com",$secpasswd)
#Send-MailMessage -SmtpServer "smtp.office365.com" -Credential $PWD -to "sumit.raj@ekaplus.com" -From "sumit.raj@ekaplus.com" -Body "tEST" -Subject "Testsample"
Send-MailMessage -SmtpServer "smtp.gmail.com " -Credential $PWD -to "sumit.raj@ekaplus.com" -From "sumit.raj0103@gmail.com" -Body "tEST" -Subject "Testsample" -Port 587



}

#GetLatestFile $SourceP $TargetP


# Real time for Logging
function GetRealtime{


  $date=(get-date).ToString("dd-MM-yyyy:hh:mm:ss")
  return $date

 }
##########################################################################
#
# This Function used for Processing the Folder which has the latest change
#
##########################################################################

function ProcessFolder{
Param(
[Parameter(mandatory=$true)][String]$SFPath,
[Parameter(mandatory=$true)][String]$TFPath)


try{
   
    $SFPath
    $TFPath
    
    $Items=Get-ChildItem -Path $SFPath | Where-Object {$_.LastWriteTime.ToString('yyyyMMdd') -ge $Global:Date }
    
    foreach($item in $Items){

    if((get-item "$SFPath\$item") -is [System.IO.DirectoryInfo]){

    ProcessFolder "$SFPath\$item" "$TFPath\$item"

    }
    else{

    ProcessFile $Item $SFPath $TFPath

    }

    }

    }
    catch{

    $time=GetRealtime
    $Message="Exception: Occured during the Process of Folder $SFPath"+$_.Exception
    "`n $time $Message" | out-file -FilePath $LogP\$LogFile -Append


    }
}

##########################################################################
#
# This Function used for Processing all the latest files
#
##########################################################################
Function processFile{
param(
[parameter(mandatory=$true)][string]$item,
[Parameter(mandatory=$true)][string]$SFPath,
[Parameter(mandatory=$true)][string]$TFPath)

try{

    if([System.IO.Directory]::Exists($TFPath)){

    $time=GetRealtime
    "`n $time Info: Copying..the file:: $SFPath\$item " | out-file -FilePath $LogP\$LogFile -Append

    Copy-Item $SFPath\$item -Destination $TFPath -Force
    "`n $time Info: Copied the file:: $SFPath\$item to TargetPath:: $TFPath " | out-file -FilePath $LogP\$LogFile -Append

    }
    else{

    #New-Item -Path $TargetP -ItemType "directory"
    #New-Item "C:\New\raj\why" -ItemType "directory"
    $time=GetRealtime
    "`n $time Info: Creating the Directory:: $TFPath" | out-file -FilePath $LogP\$LogFile -Append

    New-Item -ItemType "directory" -Path $TFPath

    $time=GetRealtime
    "`n $time Info: Created the Directory:: $TFPath" | out-file -FilePath $LogP\$LogFile -Append

    $time=GetRealtime
    "`n $time Info: Copying..the file:: $SFPath\$item " | out-file -FilePath $LogP\$LogFile -Append

    Copy-Item $SFPath\$item -Destination $TFPath -Force
    $time=GetRealtime
    "`n $time Info: Copied the file:: $SFPath\$item " | out-file -FilePath $LogP\$LogFile -Append

    }

}
catch{

    $time=GetRealtime
    $Message="Exception: Occured during the Process of File"+$_.Exception
    "`n $time $Message" | out-file -FilePath $LogP\$LogFile -Append



}



}
####################################################
#
# Travesing throught the Source Folder
# 
#####################################################
function CPUFilesFolders{
param(
[parameter(mandatory=$true)][String]$SR_Path,
[parameter(mandatory=$true)][String]$TR_Path)

try{

     if([System.IO.Directory]::Exists($SR_Path)){

     $items=Get-ChildItem -path $SR_Path |  Where-Object {$_.LastWriteTime.ToString('yyyyMMdd') -ge $Global:Date }

     foreach($item in $items){


     if((get-item "$SR_Path\$item") -is [System.IO.DirectoryInfo]){
     
        if($item -in $DesktopAppFolder){
        ProcessFolder "$SR_Path\$item" "$TR_Path\$item"
        }
        else{

        Write-Verbose -Verbose "Skipping as $item is not part of the Desktop App"

        }

     }
     else{

     ProcessFile $item $SR_Path $TR_Path
     }
     }
     }
     else{
     $time=GetRealtime
     "`n $time Info: SourcePath does not exist: $SR_Path " | out-file -FilePath $LogP\$LogFile -Append
     }
   
}
catch{

    $time=GetRealtime
    $Message="Exception: Occured during the Process of Files and Folder"+$_.Exception
    "`n $time $Message" | out-file -FilePath $LogP\$LogFile -Append


}
}

# For Debugging 
#[String]$SourceP="C:\Project\Software"
#[String]$TargetP="C:\Project\Target"
#[String]$LogP="C:\Project\Software\Logs"
#$ScriptRootPath="D:\Scripts"
#$time=GetRealtime
#"`n $time Info: Copying.." | out-file -FilePath $LogP\$LogFile -Append



############################################
#
#
# Copy Complete Folder or files from Source Path to destination
#
############################################


Function CopyAllFilesFolders{

param(
[parameter(mandatory=$true)][string]$Source_Path,
[parameter(mandatory=$true)][string]$Target_Path)

try{

    if([System.IO.Directory]::Exists($Source_Path)){

    
        if([System.IO.Directory]::Exists($Target_Path)){

        $LatestFile=Get-ChildItem -Path $Source_Path

	    foreach($File in $LatestFile){

	    Write-Host "the File is " $File
        #"`n Info: File is $File" | out-file -FilePath $LogP\$LogFile -Append 
	    "`n Info: Copying... $File" | out-file -FilePath $LogP\$LogFile -Append
	    Copy-Item $Source_Path\$File -Destination $Target_Path -Recurse -Force
        "`n Info: Copied $File to $Target_Path" | out-file -FilePath $LogP\$LogFile -Append

	    }
	
	    }
        
        else{
        
        $time=GetRealtime
        "`n $time Info: TargetPath does not exist: $Target_Path " | out-file -FilePath $LogP\$LogFile -Append
        
        }   
    }
    else{

    $time=GetRealtime
    "`n $time Info: SourcePath does not exist: $Source_Path " | out-file -FilePath $LogP\$LogFile -Append
    }

}
catch{

    
    $time=GetRealtime
    $Message="Exception: Occured during the Process of Files and Folder"+$_.Exception
    "`n $time $Message" | out-file -FilePath $LogP\$LogFile -Append



}

}



######################################
#
#Function call 
#
####################################

#Debugging
$SourceP="C:\Dev\Binaries"
$TargetP="C:\Dev\Target"

#Copy Desktop Application

if([System.IO.Directory]::Exists("$TargetP\InSightCMProd")){

    CPUFilesFolders "$SourceP\build" "$TargetP\InSightCMProd"

}
else{

 New-Item -Path "$TargetP\InSightCMProd" -ItemType Directory

 CPUFilesFolders "$SourceP\build" $TargetP

}



#Copy Services Folder

if([System.IO.Directory]::Exists("$TargetP\Services")){

CopyAllFilesFolders "$SourceP\build\Services" "$TargetP\Services"


}
else{

 New-Item -Path "$TargetP\Services" -ItemType Directory

 CopyAllFilesFolders "$SourceP\build\Services" "$TargetP\Services"

}

#Copy Spreadsheet

if([System.IO.Directory]::Exists("$TargetP\Spreadsheets")){

CopyAllFilesFolders "$SourceP\Spreadsheets" "$TargetP\Spreadsheets"


}
else{

 New-Item -Path "$TargetP\Spreadsheets" -ItemType Directory

 CopyAllFilesFolders "$SourceP\Spreadsheets" "$TargetP\Spreadsheets"

}






